CreateFrame("Frame", "TooltipIcon", ItemRefTooltip)
TooltipIcon:SetPoint("TOPRIGHT", ItemRefTooltip, "TOPLEFT", -3, -3)
TooltipIcon:SetWidth(38)
TooltipIcon:SetHeight(38)
--TooltipIcon:SetBackdrop({bgFile = ""})
TooltipIcon:Hide()

local HookSetItemRef = SetItemRef
function SetItemRef(self, link)
	local _, _, linkText = string.find(link, "|H(.-)|h") -- получаем все что между "|H" и ближайшим "|h"
	local type, arg1, arg2, arg3  = strsplit(":", linkText)
	if type == "item" then
		HookSetItemRef(self, link)
		local _, _, _, _, _, _, _, _, itemTexture = GetItemInfo(linkText)
		if itemTexture then
			TooltipIcon:SetBackdrop({bgFile = itemTexture})
			TooltipIcon:Show()
		else
			DEFAULT_CHAT_FRAME:AddMessage("Вместо текстуры я получил nil, пожалуйста, сообщите об этом автору аддона")
		end
	else
		DEFAULT_CHAT_FRAME:AddMessage("Что-то пошло не так, пожалуйста, сообщите об этом автору аддона")
	end
end